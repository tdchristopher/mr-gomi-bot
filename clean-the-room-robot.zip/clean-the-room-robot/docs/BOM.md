# MVP Hardware Bill of Materials

From PRD v1 Appendix B. Budget prices are planning estimates (as of 2026-09-15) — verify seller, exact chip/module, and live price before buying.

| Priority | Hardware | Required specification | Budget price |
|---|---|---|---|
| 1 | VL53L5CX ToF breakout | **VL53L5CX** multi-zone 8×8 / 64-zone breakout; *not* VL53L0X/VL53L1X | ~$20–35 |
| 2 | TCS34725 color sensor | TCS34725 RGB+C breakout, I²C; controlled/fill illumination preferred | ~$10–15 |
| 3 | ESP32 development board | ESP32 DevKit / ESP32-WROOM style board | ~$9–15 |
| 4 | Breadboard + jumper + resistor kit | Solderless breadboard, jumper wires, **220–330 Ω resistors** | ~$10–20 |
| 5 | RGB + white LEDs | **Common-cathode 5 mm RGB LED** plus white LEDs | ~$5–10 |
| 6 | USB cable | Cable matching selected ESP32 board | ~$5–8 |

**Estimated total (if nothing already owned): ~$59–$103.** Largest uncertainty is the VL53L5CX breakout.

## Purchase checks

1. Listing explicitly says **VL53L5CX**.
2. Prefer a **breakout/development module**, not the bare VL53L5CX IC.
3. Confirm the TCS34725 listing is an actual **TCS34725** breakout.
4. Confirm the RGB LED is **common cathode**.
5. Confirm the ESP32's USB connector (USB-C or Micro-USB) before buying a cable.
6. Don't buy chassis/motors for the October MVP unless needed separately for Phase 2.
