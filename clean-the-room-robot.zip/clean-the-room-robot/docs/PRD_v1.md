# Clean the Room Robot — Product Requirements Document (PRD v1)

| | |
|---|---|
| **Project** | Clean the Room |
| **MVP** | Stationary CAN / NOT-CAN perception prototype |
| **MVP target** | October 20–21, 2026 |
| **Competition** | November 8, 2026 |
| **Primary controller** | ESP32 |
| **Status** | MVP architecture defined; sensing assumptions remain subject to experimental validation |

> Superseded in part by [PRD v2](PRD_v2.md). Original PDF: [original/PRD_v1.pdf](original/PRD_v1.pdf)

---

## 1. Project Overview

### 1.1 Product

The project is a robot that can perceive an object's color and determine whether the object meets the criteria for a can. The October MVP isolates the perception capability before building the mobile robot.

The MVP shall answer:

> **Can a low-cost embedded system determine whether an observed object is a can by combining color sensing with simple physics- and calculus-based spatial reasoning about where a can could exist in 3D space?**

The sensing and classification method shall be determined experimentally rather than assumed to work in advance.

### 1.2 October MVP Success

The October MVP is successful when a stationary prototype can:

1. obtain sensor measurements from controlled test objects;
2. classify an object as CAN, NOT CAN, or UNKNOWN;
3. classify supported can colors as RED, GREEN, BLUE, or UNKNOWN;
4. communicate the result through LEDs;
5. log the measurements and classification results; and
6. achieve **≥70% CAN / NOT-CAN accuracy** on a balanced, independent acceptance test under documented controlled conditions.

The MVP does **not** require a chassis, wheels, motors, navigation, pickup, or transportation.

### 1.3 Downstream Product Chain

```text
SEE → IDENTIFY → MOVE → APPROACH → PICK UP
```

The October MVP proves **SEE → IDENTIFY**.

---

## 2. User / System Scenario

```text
OBJECT
  ↓
SENSE
  ↓
COLOR + SPATIAL MEASUREMENTS
  ↓
GEOMETRIC FEATURE EXTRACTION
  ↓
CAN / NOT CAN / UNKNOWN
  ↓
IF CAN → COLOR CLASSIFICATION
  ↓
LED OUTPUT
```

The user may manually place objects in front of the stationary sensor rig. Color and CAN identity are separate perception problems. **Color does not determine whether an object is a can.**

---

## 3. CAN Classification Specification

### 3.1 Numerical CAN Signature

The classifier shall use experimentally derived numerical geometric ranges rather than a purely semantic rule such as "looks like a can." Candidate features include:

- width;
- height;
- horizontal depth profile;
- cylinder-like curvature;
- vertical width consistency; and
- other geometric features supported by experimental evidence.

Distance is primarily an input used to derive geometry, not an intrinsic CAN criterion.

### 3.2 Initial Classifier Hypothesis

$$CAN = WidthMatch \land HeightMatch \land CylinderMatch$$

A candidate fourth condition is `WidthConsistencyMatch`. This feature shall become required only if experiments show that the selected sensor can measure it reliably and that it improves classification.

### 3.3 Three CAN States

- **CAN:** all required CAN criteria were measured reliably and passed.
- **NOT CAN:** sufficient evidence exists and at least one required criterion failed.
- **UNKNOWN:** one or more required criteria could not be measured reliably enough to decide.

**UNKNOWN ≠ NOT CAN.**

---

## 4. Perception & Measurement Design

### 4.1 Color Sensor — TCS34725

```text
Incoming light
  ↓
IR-blocking filter
  ↓
Red / Green / Blue / Clear filtered photodiodes
  ↓
Analog electrical signals
  ↓
ADC
  ↓
Digital R / G / B / Clear values
  ↓
I²C
  ↓
ESP32
  ↓
RED / GREEN / BLUE / UNKNOWN
```

The system shall distinguish physical units from software representations:

| Stage | Representation |
|---|---|
| Desired output | RED / GREEN / BLUE / UNKNOWN |
| Physical input | Electromagnetic radiation |
| Relevant optical property | Wavelength, commonly represented in nm |
| Sensor measurement | Analog electrical response |
| Conversion | ADC |
| Sensor output | Digital R/G/B/C counts |
| Communication | I²C digital data |
| ESP32 representation | Numeric channel values |
| Derived output | Categorical color classification |

Exact software data types shall be verified against the selected library and hardware documentation.

### 4.2 Illumination & Ambient Light Control

Ambient illumination can alter reflected-light measurements. The MVP shall use controlled illumination and repeatable sensor-to-object geometry.

The experiment shall compare at least:

- normal ambient light + controlled illumination; and
- light-shielded conditions + controlled illumination.

Controlled variables include object, sensor, illumination source, sensor distance, angle, sensor settings, and number of readings. Measurements shall be evaluated for repeatability using appropriate descriptive statistics such as mean, range, and/or standard deviation.

### 4.3 Spatial & Geometric Measurement

The initial spatial-sensing candidate is the **VL53L5CX multi-zone Time-of-Flight sensor**. Spatial measurements are represented conceptually as $d(x,y)$, where $(x,y)$ identify a sensor zone and $d$ is measured depth.

Candidate derived measurements include:

- foreground/background segmentation;
- horizontal boundary;
- vertical boundary;
- width $w$;
- height $h$;
- horizontal depth profile $d(x)$;
- first depth difference / approximate derivative;
- second depth difference / curvature-related feature; and
- vertical width profile $w(y)$.

#### Horizontal surface change

$$d'(x) \approx \frac{\Delta d}{\Delta x}$$

A cylindrical surface may produce a depth pattern that becomes closer toward its center and farther toward its edges.

#### Curvature-related change

A discrete second difference or approximate $d''(x)$ may provide curvature evidence. Nonzero curvature alone does **not** establish CAN identity.

#### Vertical width profile

Object width may be modeled as $w(y)$. For a straight-sided can, width is expected to remain approximately constant across much of its height:

$$\frac{\Delta w}{\Delta y} \approx 0$$

A tapered bottle may show larger width changes toward its neck.

Material-based discrimination is a possible future feature but is out of scope for the October MVP unless geometry proves insufficient and schedule permits.

### 4.4 CAN / NOT-CAN Classification Logic

```text
COLOR PIPELINE
TCS34725 → R/G/B/C → RED/GREEN/BLUE/UNKNOWN

CAN PIPELINE
Spatial sensor → d(x,y) → geometric features → CAN/NOT CAN/UNKNOWN
```

The classifier uses required conditions rather than majority voting.

### 4.5 System Output & LED Behavior

CAN identity has priority over color for physical output.

| CAN Classification | Color Classification | LED Behavior |
|---|---|---|
| CAN | RED | Solid red |
| CAN | GREEN | Solid green |
| CAN | BLUE | Solid blue |
| CAN | UNKNOWN | Cycle red → green → blue |
| NOT CAN | Any | Solid white |
| UNKNOWN | Any | Flashing white |

The color of a NOT-CAN object does not need to be communicated.

---

## 5. MVP Scope & Non-Scope

### 5.1 Scope Statement

> **October MVP = Stationary Perception Prototype**

### 5.2 In Scope

- ESP32 embedded controller
- TCS34725 color sensing
- controlled illumination
- RED / GREEN / BLUE / UNKNOWN color classification
- multi-zone spatial sensing investigation
- numerical depth measurements
- geometric feature extraction
- CAN / NOT CAN / UNKNOWN classification
- LED output state machine
- calibration experiments
- balanced independent acceptance testing
- data logging
- documentation of assumptions, thresholds, failures, and limitations

### 5.3 Explicitly Out of Scope

- chassis
- wheels
- motors / drivetrain
- autonomous movement
- room navigation or mapping
- localization
- path planning
- autonomous object searching
- approaching objects
- gripper / robotic arm
- object pickup
- transportation
- depositing cans
- production enclosure
- arbitrary household-object recognition
- machine-learning recognition
- camera vision unless experiments later justify it
- perfect classification
- arbitrary uncontrolled environmental operation

### 5.4 Scope Protection Rule

Before adding functionality, ask:

> **Is this capability necessary to prove CAN / NOT-CAN perception by October?**

If no, defer it to Phase 2 or later.

---

## 6. Functional Requirements

### 6.1 Color

- **FR-COLOR-01:** Obtain digital R/G/B/C measurements from the TCS34725.
- **FR-COLOR-02:** Classify supported colors as RED, GREEN, BLUE, or UNKNOWN.
- **FR-COLOR-03:** Derive/tune thresholds experimentally.
- **FR-COLOR-04:** Use controlled illumination and repeatable sensor geometry.
- **FR-COLOR-05:** Characterize measurement variation before finalizing illumination.

### 6.2 Spatial

- **FR-SPATIAL-01:** Evaluate a low-cost multi-zone spatial sensor.
- **FR-SPATIAL-02:** Associate usable distance readings with spatial zones.
- **FR-SPATIAL-03:** Represent spatial measurements conceptually as $d(x,y)$.
- **FR-SPATIAL-04:** Record numerical spatial measurements.
- **FR-SPATIAL-05:** Investigate foreground/background separation.
- **FR-SPATIAL-06:** Do not silently interpret insufficient spatial information as NOT CAN.

### 6.3 Geometry

- **FR-GEOM-01:** Investigate horizontal and vertical object boundaries.
- **FR-GEOM-02:** Investigate width and height estimation.
- **FR-GEOM-03:** Investigate $d(x)$.
- **FR-GEOM-04:** Investigate $d'(x) \approx \Delta d / \Delta x$.
- **FR-GEOM-05:** Investigate $d''(x)$ or equivalent discrete curvature evidence.
- **FR-GEOM-06:** Investigate cylinder-like geometry.
- **FR-GEOM-07:** Investigate $w(y)$ as a candidate straight-sidedness feature.
- **FR-GEOM-08:** Derive geometric thresholds experimentally.
- **FR-GEOM-09:** Do not assume curvature alone establishes CAN identity.

### 6.4 Classification

- **FR-CLASS-01:** Output CAN, NOT CAN, or UNKNOWN.
- **FR-CLASS-02:** Keep color independent from CAN identity.
- **FR-CLASS-03:** Use required geometric conditions rather than majority voting.
- **FR-CLASS-04:** Return CAN only when all required criteria are reliably evaluated and passed.
- **FR-CLASS-05:** Return NOT CAN when sufficient evidence exists and a required criterion fails.
- **FR-CLASS-06:** Return UNKNOWN when required evidence cannot be reliably measured.
- **FR-CLASS-07:** Derive final thresholds experimentally.

### 6.5 Data

Formal trials shall retain:

```text
trial_id
object_id
true_object_class
R
G
B
Clear
depth_grid
estimated_width
estimated_height
curvature_feature
width_consistency_feature
predicted_can_class
predicted_color
lighting_condition
sensor_distance
notes
```

The final schema shall contain only fields supported by the implemented hardware.

---

## 7. Testing & Acceptance Criteria

### 7.1 Primary Target

> **CAN/NOT-CAN Accuracy ≥ 70%**

This is an MVP engineering target, not a claim of statistical generalization to arbitrary environments.

### 7.2 Balanced Test Set

The formal acceptance test shall contain equal numbers of CAN and NOT-CAN trials. An initial test may contain:

```text
10 CAN trials
10 NOT-CAN trials
-----------------
20 total trials
```

### 7.3 Accuracy

$$Accuracy = \frac{N_{correct\ CAN} + N_{correct\ NOT\text{-}CAN}}{N_{all\ trials}} \times 100\%$$

UNKNOWN remains in the denominator and does not count as correct. For 20 trials, $14/20 = 70\%$. Therefore, at least **14 of 20** trials must be correctly classified.

### 7.4 UNKNOWN Rate

$$UNKNOWN\ Rate = \frac{N_{UNKNOWN}}{N_{all\ trials}} \times 100\%$$

UNKNOWN rate shall be reported separately as a diagnostic metric.

### 7.5 Calibration vs. Acceptance Set

Calibration objects shall be used to:

1. collect measurements;
2. investigate features;
3. establish numerical ranges;
4. tune thresholds; and
5. build the classifier.

After calibration, classifier thresholds shall be **frozen**. The formal acceptance test shall use different physical objects that were not used to tune the classifier.

### 7.6 Negative Test Objects

The NOT-CAN set shall include both:

- **Easy negatives:** boxes, balls, irregular objects, and clearly different geometries.
- **Tricky negatives:** bottles, cups, jars, other cylinders, and objects sharing can-like width/height/curvature.

Difficult objects shall not be removed solely because the classifier performs poorly on them.

### 7.7 Spatial Acceptance

The sensor shall be experimentally evaluated for:

- distance;
- foreground/background separation;
- boundaries;
- width;
- height;
- $d(x)$;
- $d'(x)$;
- curvature-related features; and
- $w(y)$, if supported.

Unsupported or unreliable features may be removed. The final classifier shall use only features demonstrated to be sufficiently measurable.

### 7.8 Definition of Done

| Area | Definition of Done |
|---|---|
| Hardware | ESP32 + color sensor + spatial sensor + LEDs operate on stationary rig |
| Color | R/G/B/C measurements and supported color classification demonstrated |
| Spatial | Numerical spatial measurements collected |
| Geometry | Experimentally supported features derived |
| CAN signature | Numerical criteria established from calibration data |
| Classifier | CAN / NOT CAN / UNKNOWN implemented |
| Output | LED state machine works |
| Independence | Calibration and acceptance objects are separate |
| Balance | Equal CAN and NOT-CAN acceptance trials |
| Negatives | Easy + tricky negatives included |
| Accuracy | ≥70% primary CAN/NOT-CAN accuracy |
| UNKNOWN | Included in denominator and separately reported |
| Documentation | Setup, thresholds, data, failures, and limitations recorded |
| Mobility | Not required |

---

## 8. Hardware & Software Architecture

### 8.1 Architecture

```text
                OBJECT
                  ↓
       ┌──────────┴──────────┐
       ↓                     ↓
   TCS34725              VL53L5CX
 Color Sensor            ToF Imager
       ↓                     ↓
    R/G/B/C               d(x,y)
       └──────────┬──────────┘
                  ↓
                ESP32
                  ↓
      ┌───────────┴───────────┐
      ↓                       ↓
COLOR CLASSIFIER      GEOMETRY PIPELINE
      ↓                       ↓
R/G/B/UNKNOWN      width / height / profile
                              ↓
                       CAN CLASSIFIER
                              ↓
                 CAN / NOT CAN / UNKNOWN
                              ↓
                        OUTPUT LOGIC
                              ↓
                    RGB LED + WHITE LED
                              ↓
                          DATA LOG
```

### 8.2 Hardware Baseline

| Component | Selection | Responsibility |
|---|---|---|
| Controller | ESP32 development board | Sensing, math, classification, LEDs, logging |
| Color sensor | TCS34725 breakout | R/G/B/C measurements |
| Spatial sensor | VL53L5CX breakout | Multi-zone ToF depth measurements |
| Color output | Common-cathode RGB LED | CAN color output |
| Class output | White LED | NOT CAN / UNKNOWN output |
| Prototyping | Breadboard + jumpers | Temporary integration |
| LED protection | 220–330 Ω resistors | Current limiting |
| Power/programming | USB cable | ESP32 power/programming |

The **VL53L5CX is the first spatial sensor to test**, not an assumption that all proposed geometry can be recovered from its depth grid.

### 8.3 Software Modules

```text
main
├── color_sensor
├── spatial_sensor
├── color_classifier
├── geometry
├── can_classifier
├── output_controller
└── logger
```

Initial development environment:

- Arduino IDE
- ESP32 board support
- TCS34725-compatible Arduino library
- VL53L5CX-compatible Arduino library
- Serial Monitor
- GitHub

### 8.4 Core Architecture Principle

```text
Sensors → ESP32 → Physics/Math → Classification → Output
```

Raw sensor readings shall not directly establish CAN identity.

---

## Appendix A — Physics & Mathematical Reference Model

### A.1 Traceability

```text
PHYSICAL WORLD → SENSOR → PHYSICS → MATHEMATICAL REPRESENTATION → DERIVED FEATURE → CLASSIFICATION
```

### A.2 Time-of-Flight Distance

If emitted light travels to an object and returns to the sensor:

$$2d = v\Delta t \quad\Rightarrow\quad d = \frac{v\Delta t}{2}$$

where $d$ = one-way object distance; $v$ = propagation speed of light in the relevant medium; $\Delta t$ = measured round-trip time.

Dimensional check: $(m/s)(s) = m$. The division by two accounts for the outgoing and returning paths.

### A.3 Spatial Depth

$d(x,y)$ represents measured distance as a function of horizontal and vertical sensor-zone position.

### A.4 Surface Slope

For discrete measurements, $d'(x) \approx \Delta d / \Delta x$.

Example depth profile: `12 → 10 → 9 → 10 → 12`
First differences: `-2, -1, +1, +2`

This describes how depth changes across the observed surface.

### A.5 Curvature

Second differences describe how the first differences change. For the example above: `+1, +2, +1`.

A flat idealized profile `10 → 10 → 10 → 10 → 10` has zero first and second differences.

Curvature is evidence about shape, not proof of CAN identity.

### A.6 Geometric Size

Candidate geometric measurements include $w$ = object width and $h$ = object height. For an upright cylindrical object viewed from the side, visible width may approximate diameter under appropriate assumptions: $D \approx w$ and $r \approx D/2$.

These relationships shall only be used where the experimental geometry supports them.

### A.7 Vertical Width Consistency

$w(y)$ represents estimated object width at vertical position $y$. A straight-sided can may satisfy approximately $\Delta w / \Delta y \approx 0$ across much of its body. This is a candidate discriminator between cans and tapered cylindrical objects such as bottles.

### A.8 MVP Validation Principle

> **The mathematics defines the information we would like to extract. Experiments determine what the hardware can actually measure.**

A feature that cannot be measured reliably may be simplified or removed from the October classifier.

---

## Appendix B — MVP Hardware Purchase List

See [`BOM.md`](BOM.md).

---

## Appendix C — Phase Boundary

```text
PHASE 1 — PERCEPTION
SEE → MEASURE → IDENTIFY → CAN / NOT CAN
──────────── MVP GATE ────────────
PHASE 2 — ROBOTICS
MOUNT → MOVE → SEARCH → APPROACH → INTERACT
```

- **Phase 1 target:** October 20–21, 2026
- **Competition:** November 8, 2026

The perception subsystem should be validated before mobility and physical robot integration are allowed to expand the MVP scope.
