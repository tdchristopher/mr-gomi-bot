# Clean the Room Robot — Updated PRD (v2)

**2026-09-17**

> This revision incorporates technical review findings and the official RSSC "Clean the Room" contest rules discovered after the original PRD was drafted. It supersedes the [original PRD](PRD_v1.md) where they conflict; unchanged sections (project overview, hardware baseline, purchase list) carry forward and are referenced rather than repeated. Original PDF: [original/PRD_v2.pdf](original/PRD_v2.pdf)

---

## 1. Scope & Priority Triage

Not every gap identified in review carries the same urgency. Items are grouped by what they block.

| Priority | Item | Why it matters |
|---|---|---|
| MVP-blocking | ToF-vs-specular-metal test | Determines whether curvature/width features are trustworthy on real cans |
| MVP-blocking | Zone-to-real-world-units conversion | Width/height features are undefined without it |
| MVP-blocking | 8x8 zone resolution check | Decides whether curvature is required or candidate-only |
| MVP-blocking | Operational definition of "reliably measured" | UNKNOWN state has no rule without it |
| MVP-blocking | Test-data hygiene (props excluded from acceptance set) | Protects the validity of the 70% accuracy claim |
| MVP-blocking | Non-blocking LED timing | LED output requirement fails during a live demo otherwise |
| MVP-blocking (lower severity) | Sensor co-registration | Affects color/CAN pairing accuracy, not core CAN/NOT-CAN metric |
| Contest-specific (Nov 8) | Modified vs. unmodified can strategy | Contest rules score each differently; changes which cans to build thresholds around |
| Contest-specific (Nov 8) | "Task complete" signal | New scoring category with no corresponding output state yet |
| Contest-specific (Nov 8) | CAN/NOT-CAN scope recheck | Contest room has no clutter to reject; changes how much of the geometric classifier is essential |
| Schedule risk | MVP-to-competition compression | ~19 days between the Oct 20–21 gate and Nov 8; Phase 2 (mobility, pickup) is compressed into that window |

Sections 2–8 below address each row.

---

## 2. Contest Requirements Reconciliation

The official RSSC "Clean the Room" rules (rssc.org/clean-the-room.html) were not available when the original PRD's CAN/NOT-CAN classifier was scoped. The findings change the picture:

1. **The room contains no clutter to reject.** Three soda cans, red/blue/green, are placed near the center by a non-contestant. There is no bottle, cup, or box the robot must distinguish from a can. The original PRD's tricky-negative discrimination (bottles, jars, other cylinders) targets a harder, more general problem than the contest scores.
2. **The contest explicitly sanctions bringing your own modified cans.** The rules note that provided cans may not work reliably with color sensors, so bringing your own is recommended. This resolves the earlier open question about wrapped/modified cans — for competition day (not for the frozen-threshold acceptance test), using your own solid-color cans is the club's own recommended approach.
3. **Scoring rewards, but doesn't require, unmodified-can detection.** Signaling the correct color of a modified can and of an unmodified manufactured can are each worth 10 points, scored separately. Unmodified detection is a stretch goal, not the baseline.
4. **A "task complete" signal is a separate scored item** (10 points) with no equivalent in the current LED state machine — addressed in Section 5.

**Decision needed:** target modified (own) cans as the MVP/contest baseline, with unmodified-can detection as a stretch goal attempted only if time permits after the Oct 20–21 gate.

---

## 3. Perception & Measurement Design Updates

Four additions to Section 4 of the original PRD, to be resolved before geometric thresholds are frozen.

### 3.1 ToF-vs-specular-metal test (new, precedes all geometry work)

Aluminum can surfaces are specular; time-of-flight sensors are calibrated against diffuse reflectance and can return noisy or invalid depth off shiny metal. Labeled cans are lower risk than bare metal since the label covers most of the body, but this must be verified, not assumed.

**Protocol:**

1. Fix distance and angle. Compare a labeled can (body center) against a matte diffuse control (painted cardboard) at the same distance.
2. Log 50–100 samples of `target_status`, `range_sigma_mm`, and signal strength (`signal_per_spad_kcps`) for both.
3. Repeat at 2–3 angles (0°, ±20°) and 2 distances (near/far end of planned operating range).

**Decision gate:**

| Result | Action |
|---|---|
| Sigma/validity comparable to control | Proceed with curvature/width features as planned |
| Noisy but zones still valid | Downgrade curvature and w(y) to candidate-only; keep width/height from silhouette (zone validity), which is more robust to depth noise than derivative-based features |
| Zones going invalid | Fallback ladder: increase integration time → reduce ranging frequency → move object closer → (MVP-scoped only) matte strip on test can centerline, documented as a limitation |

### 3.2 Zone-to-real-world-units conversion (missing from original spec)

The VL53L5CX reports distance per zone plus a known angular field of view per zone. Physical width is not read directly — it must be derived:

$$width \approx 2 \cdot d \cdot \tan(\theta_{half})$$

where $d$ is the zone's measured depth and $\theta_{half}$ is half the angular width subtended by the zone(s) spanning the object. This conversion step is now a required part of FR-GEOM-02 (width/height estimation) and must be implemented before any width threshold is tuned.

### 3.3 8x8 zone resolution check

A standard can is ~6.6 cm wide. At the planned test distance, the number of zones actually landing on the can's body must be calculated before curvature (second difference) is treated as more than a candidate feature — first/second differences over 2–3 data points are unreliable. Record zones-on-target at the chosen distance as part of calibration documentation.

### 3.4 Sensor co-registration

TCS34725 and VL53L5CX have separate optical axes. Confirm at rig build time that both sensors are aimed at the same point on the test object, especially for off-center placements, so that color and depth readings describe the same physical location.

---

## 4. Classification Logic — Operationalized Reliability Criteria

The original PRD used "reliably measured" throughout Sections 3.3 and 6.4 to distinguish NOT CAN from UNKNOWN, without defining it. This section fills that gap.

A required criterion (WidthMatch, HeightMatch, CylinderMatch) is **reliably measured** only when all of the following hold for the relevant sensor reading:

| Check | Threshold (to be tuned during calibration) |
|---|---|
| ToF zone validity | `target_status` indicates a valid return for the zones spanning the feature |
| Measurement noise | `range_sigma_mm` below a calibration-derived ceiling |
| Repeatability | Standard deviation across N repeated readings (N set during calibration) below a calibration-derived ceiling |
| Signal strength | `signal_per_spad_kcps` above a minimum floor (distinguishes a real return from background/no-target) |

**Classification rule, restated with this definition:**

- **CAN:** all required criteria are reliably measured (per the checks above) AND pass their geometric threshold.
- **NOT CAN:** all required criteria are reliably measured AND at least one fails its threshold.
- **UNKNOWN:** at least one required criterion fails a reliability check above, regardless of what its raw value would have classified as.

The specific numeric thresholds in each row are calibration outputs, not fixed here — but the checks themselves (which sensor fields, which statistic) are now fixed as part of the classifier's definition, closing the ambiguity in FR-CLASS-06.

---

## 5. Output & LED State Machine Updates

### 5.1 New state: task complete

The RSSC rules score "automatically stops and signals task complete" (10 points) as its own item. The original LED table (Section 4.5) has no corresponding state. Added row:

| CAN Classification | Color Classification | LED Behavior |
|---|---|---|
| CAN | RED | Solid red |
| CAN | GREEN | Solid green |
| CAN | BLUE | Solid blue |
| CAN | UNKNOWN | Cycle red → green → blue |
| NOT CAN | Any | Solid white |
| UNKNOWN | Any | Flashing white |
| **Task complete (new)** | — | Distinct pattern reserved from the above (e.g., all-LED slow pulse) — exact pattern TBD, must not collide with existing states |

For the October MVP (stationary, single-object classification), "task complete" can simply mean "classification result latched and displayed" — the full multi-can completion signal is a Phase 2 / contest-day requirement once mobility and sequencing exist.

### 5.2 Non-blocking timing (implementation note, not a new requirement)

The red → green → blue cycle state requires timing without stalling the sensor loop. Implement with a `millis()`-based state machine (track last-transition timestamp, compare against interval, advance state) rather than `delay()` calls. This is an implementation constraint on FR outputs, not a new functional requirement — flagged here because blocking delays are a common first-embedded-project bug that would otherwise silently stall sensor polling during LED cycling.

---

## 6. Testing & Data Hygiene

Section 7.5 of the original PRD already requires calibration and acceptance objects to be separate physical objects. This section adds a third bucket and a rule for keeping it out of the accuracy claim.

| Bucket | Contents | Use |
|---|---|---|
| Calibration set (frozen after tuning) | Real cans (multiple brands/finishes) + easy negatives (box, ball) + tricky negatives (bottle, cup, jar) | Tune thresholds, then freeze |
| Acceptance set (independent) | Different real cans and negatives than calibration | Formal 70% accuracy trials (Section 7 of original PRD) |
| Diagnostic-only set (new) | Cardboard-wrapped can, matte diffuse control, other variable-isolation props | ToF-vs-metal test (Section 3.1), color-pipeline calibration reference — never entered as a calibration or acceptance trial |

**Rule:** any object built to isolate a single variable (reflectance, corrugation noise, etc.) stays in the diagnostic-only bucket permanently. If a diagnostic prop's results are worth reporting, they belong in the limitations/assumptions writeup, not in the accuracy trial count.

This distinction does not apply to contest day itself — per Section 2 above, bringing modified/wrapped cans to the Nov 8 competition is explicitly allowed and recommended by the rules. The separation matters specifically for the MVP's internal accuracy claim, where the test-of-record must reflect real, unmodified objects to be defensible.

---

## 7. Schedule Risk & Contingency

The original PRD's own phase boundary (Appendix C) places everything the October MVP explicitly excludes — chassis, wheels, motors, navigation, approach, pickup — into Phase 2, which by definition starts only after the Oct 20–21 MVP gate. The competition is Nov 8: roughly 19 days later. That window has to fit building a full mobile robot (drivetrain, navigation to three known can positions, a pickup or push/drag mechanism) on top of the perception work.

**Risk:** Phase 2 (MOUNT → MOVE → SEARCH → APPROACH → INTERACT) is compressed into ~19 days after a perception-only MVP gate.

**Contingency (in order of preference):**

1. Full autonomous mobility + pickup, as originally scoped.
2. Push/drag into the trash outline instead of a gripper-based pickup — explicitly a valid, if lower-scoring, path under the contest rules.
3. Manual-approach fallback: robot performs perception and color signaling correctly from a fixed or manually-positioned location, forgoing autonomous navigation points, to guarantee at least the color-signaling and can-disposal-adjacent scoring categories are attempted.

The order above should be revisited once real timing data exists from early Phase 2 work — this is a placeholder decision framework, not a final commitment.

---

## 8. Open Decisions Needed

Tracked in [`decisions.md`](decisions.md).
