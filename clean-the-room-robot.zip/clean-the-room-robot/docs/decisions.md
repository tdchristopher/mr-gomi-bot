# Open Decisions

From [PRD v2 §8](PRD_v2.md#8-open-decisions-needed). Check off and record the outcome + date as each is resolved.

- [ ] Run the ToF-vs-specular-metal test ([PRD v2 §3.1](PRD_v2.md#31-tof-vs-specular-metal-test-new-precedes-all-geometry-work)) and record the decision-gate outcome before freezing geometric thresholds.
  - Outcome:
- [ ] Choose modified vs. unmodified cans as the MVP/contest baseline ([PRD v2 §2](PRD_v2.md#2-contest-requirements-reconciliation)).
  - Outcome:
- [ ] Pick the exact numeric thresholds for the reliability checks ([PRD v2 §4](PRD_v2.md#4-classification-logic--operationalized-reliability-criteria)) during calibration.
  - Outcome:
- [ ] Decide the specific "task complete" LED pattern ([PRD v2 §5.1](PRD_v2.md#51-new-state-task-complete)).
  - Outcome:
- [ ] Confirm how much of the tricky-negative discrimination work (bottles, jars) is still worth building given the contest has no clutter to reject — balance against its value as Phase 2 / portfolio foundation.
  - Outcome:
- [ ] Revisit the Phase 2 contingency ladder ([PRD v2 §7](PRD_v2.md#7-schedule-risk--contingency)) once early mobility timing data exists.
  - Outcome:
