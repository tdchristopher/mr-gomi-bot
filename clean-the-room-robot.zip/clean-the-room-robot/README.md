# Clean the Room Robot

An ESP32-based robot for the RSSC **"Clean the Room"** contest: find soda cans, identify their color (red / green / blue), and get them into the trash.

The first milestone isolates **perception**: a stationary rig that decides whether an object is a can — and what color it is — using a color sensor plus physics- and calculus-based reasoning over a time-of-flight depth grid.

| Milestone | Date |
|---|---|
| Phase 1 — Perception MVP gate | October 20–21, 2026 |
| Competition | November 8, 2026 |

## How it works

```text
            OBJECT
         ┌────┴────┐
     TCS34725   VL53L5CX (8×8 ToF)
      R/G/B/C     d(x,y)
         └────┬────┘
            ESP32
   ┌──────────┴──────────┐
 color classifier   geometry pipeline
 RED/GREEN/BLUE/?   width · height · d(x) · d'(x) · d''(x) · w(y)
                         ↓
               CAN / NOT CAN / UNKNOWN
                         ↓
                 RGB + white LED · data log
```

Color and can-identity are separate problems — **color never decides whether something is a can.** The can classifier uses required conditions (width ∧ height ∧ cylinder), and returns **UNKNOWN** rather than guessing when a measurement isn't reliable.

**MVP target:** ≥70% CAN / NOT-CAN accuracy on a balanced acceptance set of objects never used for tuning (UNKNOWN counts as wrong).

## Repository layout

```text
README.md
docs/
  PRD_v1.md        original requirements
  PRD_v2.md        review findings + contest rules
  decisions.md     open decisions log
  BOM.md           hardware bill of materials
  original/        source PDFs
```

## Hardware

ESP32 DevKit · TCS34725 color sensor · VL53L5CX 8×8 ToF sensor · common-cathode RGB LED · white LED · 220–330 Ω resistors · breadboard. Full list in [`docs/BOM.md`](docs/BOM.md).

## Docs

- [PRD v1 — original requirements](docs/PRD_v1.md)
- [PRD v2 — review findings + contest rules](docs/PRD_v2.md)
- [Open decisions](docs/decisions.md)
- [Bill of materials](docs/BOM.md)

## Status

Work in progress.
